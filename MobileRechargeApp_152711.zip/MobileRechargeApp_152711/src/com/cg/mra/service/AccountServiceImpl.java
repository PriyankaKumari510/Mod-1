package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.AccountException;
import com.cg.mra.exception.AccountExceptionMessages;

public class AccountServiceImpl implements AccountService  {
	
	AccountDao dao=new AccountDaoImpl();

	@Override
	public Account getAccountDetails(String mobileNo) {
		return dao.getAccountDetails(mobileNo);
	}

	@Override
	public boolean rechargeAccount(String mobileno, double rechargeAmount) {
		return dao.rechargeAccount(mobileno, rechargeAmount);
	}


	
	public boolean validateNumber(String number) throws AccountException {
		if(!(number.matches("[0-9]+"))){
			throw new AccountException(AccountExceptionMessages.ERROR1);
		}
		return true;
	}

	@Override
	public boolean validateAmount(double amount) throws AccountException {
		
		return false;
	}
	
	
	

	}

