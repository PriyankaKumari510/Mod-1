package com.cg.mra.dao;

import com.cg.mra.beans.Account;

public interface AccountDao {
	
	Account getAccountDetails(String mobileNo);
	boolean rechargeAccount(String mobileNo, double rechargeAmount);
	

}
