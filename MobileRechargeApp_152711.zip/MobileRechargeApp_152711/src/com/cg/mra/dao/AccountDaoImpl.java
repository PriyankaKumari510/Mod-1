package com.cg.mra.dao;

import java.util.HashMap;

import com.cg.mra.beans.Account;

public class AccountDaoImpl implements AccountDao{

	
		
		public static HashMap<String, Account> hashmap=null;
		 
		static {
			HashMap hashmap = new HashMap();
			Account cus1=new Account();
			cus1.setMobileNo("9922943943");
			cus1.setAccountType("Prepaid");
			cus1.setCustomerName("Soumya");
			cus1.setAccountBalance(500.00);
			
			Account cus2=new Account();
			cus2.setMobileNo("9834391234");
			cus2.setAccountType("Postpaid");
			cus2.setCustomerName("Sravs");
			cus2.setAccountBalance(200.00);
			
			hashmap.put("9922943943",cus1);
			hashmap.put("9834391234",cus2);
			
				
		
	}

	@Override
	public Account getAccountDetails(String mobileNo) {
		
		return hashmap.get(mobileNo);
	}

	@Override
	public boolean rechargeAccount(String mobileNo, double rechargeAmount) {
		
		return true;
	}
}
