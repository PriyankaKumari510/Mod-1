package com.cg.mra.exception;

public interface AccountExceptionMessages {
	String ERROR1="Mobile number should be onlu numbers and of 10 digits only";
	String ERROR2= "Given Account Id Does Not Exists";
	String ERROR3="Name should be only Alphabets";
}
