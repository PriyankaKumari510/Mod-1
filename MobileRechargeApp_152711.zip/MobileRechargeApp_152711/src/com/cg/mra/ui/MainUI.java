package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {
	
	public static void main(String[] args) {
		
		int choice =0;
		AccountService service= new AccountServiceImpl();
		do {
			printDetails();
			System.out.println("Enter your choice");
			Scanner scanner= new Scanner(System.in);
			choice=scanner.nextInt();
			switch(choice) {
			
			case 1: System.out.println("enter mobile no");
			        String number1=scanner.next();
			        Account dto=new Account();
			        Account account1=service.getAccountDetails(number1);
			        boolean error=false;
			        try {
				    error=service.validateNumber(number1);
			        }catch (AccountException accountException) {
				    System.out.println(accountException.getMessage());
			        }
			        if(error) {
			        	Account account=service.getAccountDetails(number1);
			        	if(account!=null) {
			        		System.out.println("your current balance is"+account1.getAccountBalance());
			        	}else {
			        		System.out.println("given account does not exists");
			        	}
			        }
			        
			break;
			
			case 2: System.out.println("enter mobile no");
			String number2=scanner.next();
			System.out.println("enter recharge amount");
			double amount=scanner.nextDouble();
			service.rechargeAccount(number2, amount);
			Account account2=service.getAccountDetails(number2); 
			System.out.println(" Account recharged successfully ");
			System.out.println("Hello Sowmya,Available Balance is"+account2.getAccountBalance());
            break;
            
            
			default:
					System.exit(0);
					break;
					
			}
		}while(choice!=4);
		
	}
	private static void printDetails() {
			
		System.out.println("--------Menu------");
		System.out.println("1. Account Balance Enquiry");
		System.out.println("2. Recharge Account");
		System.out.println("3. Exit");
		
	}

}
